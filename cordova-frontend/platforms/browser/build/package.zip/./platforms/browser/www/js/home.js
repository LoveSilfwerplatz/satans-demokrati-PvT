/*

$(document).ready(function(){
    $(this).ignoreContentEnabled=true;
});


$(document).on("mobileinit", function () {
    $.mobile.ignoreContentEnabled=true;
});

*/