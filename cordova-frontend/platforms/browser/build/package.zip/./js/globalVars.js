/**
 * Created by carl-johanlindblad on 2016-05-30.
 */
// used in mapscript.js
var mapscript_pos = {};
var hardCodedPos = false;
